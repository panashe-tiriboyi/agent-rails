# Codex Adapter

Canonical project guidance is in `AGENTS.md` and `.ai/`.

Read `AGENTS.md`, then `.ai/instructions.md`. Route the task with `.ai/task-routing.md` and load context according to `.ai/context-loading-rules.md`.

For new request intake, use `docs/requirements/change-request-template.md` and update `docs/requirements/README.md`.

For approved implementation requirements, code and tests are required unless the requester explicitly asks for documentation-only work.

Do not use local tooling config as project knowledge unless `.ai/context/project-map.md` says it is authoritative.
